test = {
  'name': 'q21',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(near_twenty, 8)
          19.99909998
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
