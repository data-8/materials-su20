test = {
  'name': 'q11',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> new_year
          2020
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
