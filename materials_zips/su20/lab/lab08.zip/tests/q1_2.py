test = {
  'name': 'q1_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> mean_based_estimator(np.array([1, 2, 3])) is not None
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> int(np.round(mean_based_estimator(np.array([1, 2, 3]))))
          4
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> mean_based_estimate
          122.47058823529412
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
