test = {
  'name': 'q33',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> import math;
          >>> math.isclose(average_total_pay, 11445294.11764706, rel_tol = 0.1)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
