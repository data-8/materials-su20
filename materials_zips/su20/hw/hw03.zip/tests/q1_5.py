test = {
  'name': 'q1_5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> by_pter.take(0)
          Date       | NEI     | NEI-PTER | PTER
          2009-07-01 | 10.8089 | 12.7404  | 1.9315
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
