test = {
  'name': 'q1_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Remember, we would like 2500 bootstrapped estimates. ;
          >>> # Make sure you are also returning correctly in the function.;
          >>> len(percentages_in_resamples()) == 2500
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
