test = {
  'name': 'q1_18',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(evans_career_length_pred) in set([float, np.float32, np.float64])
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
