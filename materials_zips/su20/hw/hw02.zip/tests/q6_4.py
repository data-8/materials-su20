test = {
  'name': 'q6_4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> sales.sort(0)
          box ID | fruit name | count sold | price per fruit ($)
          25274  | apple      | 0          | 0.8
          26187  | strawberry | 25         | 0.15
          43566  | peach      | 17         | 0.8
          48800  | orange     | 35         | 0.6
          52357  | strawberry | 102        | 0.25
          53686  | kiwi       | 3          | 0.5
          57181  | strawberry | 101        | 0.2
          57930  | grape      | 355        | 0.06
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
