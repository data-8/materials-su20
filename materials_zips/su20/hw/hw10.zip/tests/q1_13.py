test = {
  'name': 'q1_13',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> 5 < rmse_example < 10
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
